using System.Windows;

namespace Barabulka2
{
    public partial class SettingsWindow : Window
    {
        private readonly MainWindow _main;
        private bool _initialized;

        public SettingsWindow(MainWindow main, AppSettings current)
        {
            InitializeComponent();
            _main = main;

            OpacitySlider.Value = current.FishOpacity;
            ClickThroughCheckBox.IsChecked = current.ClickThrough;
            OpacityLabel.Text = $"{current.FishOpacity * 100:F0}%";

            _initialized = true; // чтобы обработчики ниже не сработали раньше времени при инициализации контролов
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!_initialized) return;
            OpacityLabel.Text = $"{e.NewValue * 100:F0}%";
            _main.ApplyOpacity(e.NewValue);
        }

        private void ClickThroughCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            if (!_initialized) return;
            _main.ApplyClickThrough(ClickThroughCheckBox.IsChecked == true);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            _main.SaveCurrentSettings();
            Close();
        }
    }
}
