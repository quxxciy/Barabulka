using System;
using System.IO;
using System.Text.Json;

namespace Barabulka2
{
    /// <summary>
    /// Настройки приложения. Хранятся в %AppData%\Barabulka2\settings.json
    /// </summary>
    public class AppSettings
    {
        /// <summary>Прозрачность рыб, 0.1 (почти невидимы) .. 1.0 (непрозрачные)</summary>
        public double FishOpacity { get; set; } = 1.0;

        /// <summary>true = окно кликов не перехватывает, всё уходит "сквозь" на рабочий стол</summary>
        public bool ClickThrough { get; set; } = true;

        private static string FilePath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "Barabulka2", "settings.json");

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    string json = File.ReadAllText(FilePath);
                    var loaded = JsonSerializer.Deserialize<AppSettings>(json);
                    if (loaded != null) return loaded;
                }
            }
            catch
            {
                // Файл настроек битый/недоступен - просто едем на дефолтах, не роняем приложение
            }
            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                string dir = Path.GetDirectoryName(FilePath)!;
                Directory.CreateDirectory(dir);
                string json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(FilePath, json);
            }
            catch
            {
                // Не критично: просто настройки не переживут перезапуск
            }
        }
    }
}
